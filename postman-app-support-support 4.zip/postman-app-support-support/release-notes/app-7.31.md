We've just released version 7.31 of the Postman app. Update your app or get the latest version here: https://www.postman.com/downloads/ 🚀 

#### New Feature(s)
#4117
#4142
#5519

#### Improvement(s)
Closes #8789

See the release notes attached to that Pull Request for the full details! :) 
